
package uno;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;
import java.sql.Connection;
import java.sql.DriverManager;
import conexion.conexionmysql;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class servicios extends javax.swing.JFrame {
conexion.conexionmysql con=new conexionmysql();
Connection cn=con.conectar();
   
    public servicios() {
        initComponents();
         cargarTabla1();
         cargarTabla2();
          cargarTabla();
         jid.setVisible(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jnombre = new javax.swing.JTextField();
        jbagregars = new javax.swing.JButton();
        jbeditars = new javax.swing.JButton();
        jbeliminars = new javax.swing.JButton();
        jid = new javax.swing.JTextField();
        jr = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jt1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cic = new javax.swing.JTextField();
        ids = new javax.swing.JTextField();
        jbagregarsc = new javax.swing.JButton();
        jbeliminarse = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtc = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Servicio:");

        jLabel2.setText("Nombre:");

        jLabel3.setText("Recibo de sueldo:");

        jnombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jnombreActionPerformed(evt);
            }
        });

        jbagregars.setText("Agregar");
        jbagregars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbagregarsActionPerformed(evt);
            }
        });

        jbeditars.setText("Editar");
        jbeditars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbeditarsActionPerformed(evt);
            }
        });

        jbeliminars.setText("Eliminar");
        jbeliminars.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbeliminarsActionPerformed(evt);
            }
        });

        jr.setText("SI");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jid, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(jnombre, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jr))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jbagregars)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jbeditars)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbeliminars)))
                .addGap(24, 24, 24))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jr))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbagregars)
                    .addComponent(jbeditars)
                    .addComponent(jbeliminars))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jLabel4.setText("Servicios disponibles:");

        jt1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Resibo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jt1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jt1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jt1);

        jLabel5.setText("Persona por servicios");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "CI", "Nombre", "Apellido", "Servicio", "ID servicio", "ID relacion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(267, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(262, 262, 262))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(284, 284, 284))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(243, 243, 243))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel6.setText("Servicios clientes:");

        jLabel7.setText("CI Cliente:");

        jLabel8.setText("ID Servicio:");

        jbagregarsc.setText("Agregar");
        jbagregarsc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbagregarscActionPerformed(evt);
            }
        });

        jbeliminarse.setText("Eliminar");
        jbeliminarse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbeliminarseActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6)
                            .addComponent(cic, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(ids)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jbagregarsc)
                        .addGap(18, 18, 18)
                        .addComponent(jbeliminarse)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(cic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ids, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbagregarsc)
                    .addComponent(jbeliminarse))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 427, Short.MAX_VALUE)
        );

        jtc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "CI", "Nombre", "Apellido"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtcMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jtc);

        jButton2.setText("Limpiar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jnombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jnombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jnombreActionPerformed

    private void jbeditarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbeditarsActionPerformed
if (validarDatos()) {
        String jn = jnombre.getText();
    int id = Integer.parseInt(jid.getText());
    boolean re = jr.isSelected();
    int reInt = (re) ? 1 : 0;
    try {
        
        String consulta = "UPDATE `servicios` SET `nombre_de_servicios` = ?, `Nrecibo` = ? WHERE `id` = ?";

        java.sql.PreparedStatement ps = cn.prepareStatement(consulta);
        ps.setString(1, jn); 
        ps.setInt(2, reInt); 
        ps.setInt(3, id);

        ps.executeUpdate();

        JOptionPane.showMessageDialog(null, "Datos Modificados", "Guardado", JOptionPane.INFORMATION_MESSAGE);

        limpiar();
        cargarTabla1();
        
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
}
    }//GEN-LAST:event_jbeditarsActionPerformed

    private void jbagregarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbagregarsActionPerformed
if (validarDatos()) {
        String jn = jnombre.getText();
          boolean re = jr.isSelected();
        int reInt = (re) ? 1 : 0;
        
        try{
            
            String consulta="INSERT INTO `servicios` (`nombre_de_servicios`, `Nrecibo`) VALUES ('"+jn+"','"+reInt+"')";

        
             java.sql.PreparedStatement ps=cn.prepareStatement(consulta);
             ps.executeUpdate();
             limpiar();
             JOptionPane.showMessageDialog(null, "Datos guardados","Guardado", JOptionPane.INFORMATION_MESSAGE);
        
         cargarTabla1();
            
         }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    
    }

}
    }//GEN-LAST:event_jbagregarsActionPerformed

    private void jbeliminarsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbeliminarsActionPerformed
if (validarDatos()) {        
     
     try {
         
        int id = Integer.parseInt(jid.getText());

       
            String consulta = "DELETE FROM `servicios` WHERE `id` = ?";
    
            java.sql.PreparedStatement ps = cn.prepareStatement(consulta);
   
            ps.setInt(1, id);
    
            ps.executeUpdate();
    
            JOptionPane.showMessageDialog(null, "Datos Modificados", "Guardado", JOptionPane.INFORMATION_MESSAGE);
    
            limpiar();
            cargarTabla1();
          
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }      
}
    }//GEN-LAST:event_jbeliminarsActionPerformed

    private void jt1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jt1MouseClicked
        try {
        int fila = jt1.getSelectedRow();
        if (fila != -1) { 
            int id = Integer.parseInt(jt1.getValueAt(fila, 0).toString());
            ResultSet rs;

            java.sql.PreparedStatement ps = cn.prepareStatement("SELECT nombre_de_servicios, Nrecibo FROM servicios WHERE id=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {
                jnombre.setText(rs.getString("nombre_de_servicios"));
                jid.setText(String.valueOf(id)); 
                if (rs.getBoolean("Nrecibo")) {
                    jr.setSelected(true);
                } else {
                    jr.setSelected(false);
                }
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_jt1MouseClicked

    private void jbagregarscActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbagregarscActionPerformed

        if (validarDatos1()){
        int idCliente = Integer.parseInt(cic.getText());
        int idServicio = Integer.parseInt(ids.getText());
        try {
       

       
        boolean servicioRequiereVerificacion = servicioRequiereVerificacion(idServicio);

      
        boolean clienteVerificacionActivada = clienteVerificacionActivada(idCliente);

       
        if (!servicioRequiereVerificacion || clienteVerificacionActivada) {
            
           Timestamp fechaActual = new Timestamp(System.currentTimeMillis());
           SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
           String fechaFormateada = formatoFecha.format(new Date(fechaActual.getTime()));
            String consulta = "INSERT INTO cliente_servicio (ci, id, fecha) VALUES (?, ?, ?)";
            PreparedStatement ps = (PreparedStatement) cn.prepareStatement(consulta);
            ps.setInt(1, idCliente);
                    ps.setInt(2, idServicio);
                    ps.setTimestamp(3, fechaActual);
                    ps.executeUpdate();


            JOptionPane.showMessageDialog(null, "Asociación creada", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            limpiar();
            cargarTabla2();
         }else{
            JOptionPane.showMessageDialog(null, "Se requiere verificacion", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
        }
    }//GEN-LAST:event_jbagregarscActionPerformed

  private boolean servicioRequiereVerificacion(int idServicio) throws SQLException {
    String consulta = "SELECT Nrecibo FROM servicios WHERE ID = ?";
    try (PreparedStatement ps = (PreparedStatement) cn.prepareStatement(consulta)) {
        ps.setInt(1, idServicio);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getBoolean("Nrecibo");
            }
        }
    }
    return false;
}

private boolean clienteVerificacionActivada(int idCliente) throws SQLException {
    String consulta = "SELECT recibo_de_sueldo FROM cliente WHERE CI = ?";
    try (PreparedStatement ps = (PreparedStatement) cn.prepareStatement(consulta)) {
        ps.setInt(1, idCliente);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getBoolean("recibo_de_sueldo");
            }
        }
    }
    return false;
}
    
    
    
    
    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
       
                                      
    try {
        
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();

       
        int fila = jTable1.getSelectedRow();

        if (fila != -1) {
            
            int idServicio = Integer.parseInt(modeloTabla.getValueAt(fila, 4).toString());
            
            ResultSet rs;
            java.sql.PreparedStatement ps = cn.prepareStatement("SELECT nombre_de_servicios FROM servicios WHERE ID=?");
            ps.setInt(1, idServicio);
            rs = ps.executeQuery();
            while (rs.next()) {
                
                ids.setText(String.valueOf(idServicio));
                cic.setText(modeloTabla.getValueAt(fila, 0).toString());
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }


    }//GEN-LAST:event_jTable1MouseClicked

    private void jbeliminarseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbeliminarseActionPerformed

   
        if(validarDatos1()){
        try {
      
        DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
        int fila = jTable1.getSelectedRow();
        
     

        if (fila != -1) {
            int idt = Integer.parseInt(modeloTabla.getValueAt(fila, 5).toString());

         
            String eliminarFilaSQL = "DELETE FROM cliente_servicio WHERE IDT = ?";
            try (PreparedStatement ps = (PreparedStatement) cn.prepareStatement(eliminarFilaSQL)) {
                ps.setInt(1, idt);
                int resultado = ps.executeUpdate();

                if (resultado > 0) {
                    JOptionPane.showMessageDialog(null, "Eliminada correctamente");
                    cargarTabla2(); 
                } else {
                    JOptionPane.showMessageDialog(null, "Error al eliminar ");
                }
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }}
    }//GEN-LAST:event_jbeliminarseActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       seleccion nuevoFrame = new seleccion();
            nuevoFrame.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jtcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtcMouseClicked
         try {
        int fila = jtc.getSelectedRow();
        
        if (fila != -1) {
            String ciSeleccionada = jtc.getValueAt(fila, 0).toString();
            cic.setText(ciSeleccionada);
            
            
          
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jtcMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      limpiar();
    }//GEN-LAST:event_jButton2ActionPerformed

    
     private void cargarTabla1(){
        DefaultTableModel modeloTabla =(DefaultTableModel) jt1.getModel();
        modeloTabla.setRowCount(0);
        
       java.sql.PreparedStatement ps;
       ResultSet rs;
      ResultSetMetaData rsmd;
      int columnas;
      
     try{
        String consulta = "SELECT id,nombre_de_servicios,Nrecibo FROM servicios"; 
        ps = cn.prepareStatement(consulta);
        rs = ps.executeQuery();
        rsmd = (ResultSetMetaData) rs.getMetaData();
        columnas = rsmd.getColumnCount();

        while(rs.next()){
            Object[] filas = new Object[columnas];
            for(int i=0; i<columnas; i++){
                filas[i] = rs.getObject(i+1);
            }
            modeloTabla.addRow(filas);
        }

    } catch(Exception e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }    
    }

     
   private void cargarTabla2() {
     DefaultTableModel modeloTabla = (DefaultTableModel) jTable1.getModel();
    modeloTabla.setRowCount(0);

    PreparedStatement ps;
    ResultSet rs;
    ResultSetMetaData rsmd;
    int columnas;

    try {
        String consulta = "SELECT c.CI, c.nombre, c.apellido, s.nombre_de_servicios AS 'Nombre de Servicio', s.ID AS 'ID del Servicio', cs.IDT " +
                         "FROM cliente AS c " +
                         "INNER JOIN cliente_servicio AS cs ON c.CI = cs.ci " +
                         "INNER JOIN servicios AS s ON cs.id = s.ID";
        ps = (PreparedStatement) cn.prepareStatement(consulta);
        rs = ps.executeQuery();
        rsmd = (ResultSetMetaData) rs.getMetaData();
        columnas = rsmd.getColumnCount();

        while (rs.next()) {
            Object[] filas = new Object[columnas];
            for (int i = 0; i < columnas; i++) {
                filas[i] = rs.getObject(i + 1);
            }
            modeloTabla.addRow(filas);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}private void cargarTabla() {
    DefaultTableModel modeloTabla = (DefaultTableModel) jtc.getModel();
    modeloTabla.setRowCount(0);

    java.sql.PreparedStatement ps;
    ResultSet rs;
    ResultSetMetaData rsmd;
    int columnas;

    try {
        String consulta = "SELECT ci, nombre, apellido FROM cliente";
        ps = cn.prepareStatement(consulta);
        rs = ps.executeQuery();
        rsmd = (ResultSetMetaData) rs.getMetaData();
        columnas = rsmd.getColumnCount();

        while (rs.next()) {
            Object[] filas = new Object[3]; 
            for (int i = 0; i < 3; i++) {
                filas[i] = rs.getObject(i + 1);
            }
            modeloTabla.addRow(filas);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}



private void limpiar(){
        jnombre.setText("");
        jr.setSelected(false);
       cic.setText("");
       ids.setText("");
         
    }

public boolean validarDatos() {
      if ("".equals(jid.getText()) || "".equals(jnombre.getText()) ) {
    JOptionPane.showMessageDialog(null, "Uno o más campos están vacíos", "Error", JOptionPane.ERROR_MESSAGE);
    return false;
}

        return true;
   }

   public  boolean validarDatos1() {
     if ("".equals(cic.getText()) || "".equals(ids.getText())) {
    JOptionPane.showMessageDialog(null, "Uno o más campos están vacíos", "Error", JOptionPane.ERROR_MESSAGE);
    return false;
}
        return true;
   }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(servicios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new servicios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cic;
    private javax.swing.JTextField ids;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton jbagregars;
    private javax.swing.JButton jbagregarsc;
    private javax.swing.JButton jbeditars;
    private javax.swing.JButton jbeliminars;
    private javax.swing.JButton jbeliminarse;
    private javax.swing.JTextField jid;
    private javax.swing.JTextField jnombre;
    private javax.swing.JRadioButton jr;
    private javax.swing.JTable jt1;
    private javax.swing.JTable jtc;
    // End of variables declaration//GEN-END:variables

    private boolean existeAsociacion(int idCliente, int idServicio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
