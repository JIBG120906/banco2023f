
package uno;
import java.sql.ResultSet;
import com.mysql.jdbc.PreparedStatement;
import conexion.conexionmysql;
import java.sql.Connection;
import javax.swing.JOptionPane;


public class inicio extends javax.swing.JFrame {
conexion.conexionmysql con=new conexionmysql();
Connection cn=con.conectar();
   
    public inicio() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jt = new javax.swing.JTextField();
        jp = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Ingreso");

        jLabel2.setText("Usuario:");

        jLabel3.setText("Password:");

        jt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtActionPerformed(evt);
            }
        });

        jButton1.setText("Ingresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jToggleButton1.setText("Registrar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jt, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                            .addComponent(jp))))
                .addContainerGap(136, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jToggleButton1)
                    .addComponent(jButton1))
                .addGap(155, 155, 155))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jToggleButton1)
                .addContainerGap(78, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtActionPerformed
        
    }//GEN-LAST:event_jtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String usuarioIngresado = jt.getText();
    String contraseñaIngresada = new String(jp.getPassword());

   
    String consulta = "SELECT * FROM registro WHERE usuario = ? AND contrasena = ?";

    
    try {
        PreparedStatement pst = (PreparedStatement) cn.prepareStatement(consulta);
        pst.setString(1, usuarioIngresado);
        pst.setString(2, contraseñaIngresada);
        
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            
            JOptionPane.showMessageDialog(this, "Inicio de sesión exitoso");
            
          
            seleccion nuevoFrame = new seleccion();
            nuevoFrame.setVisible(true);
            this.dispose();
        } else {
           
            JOptionPane.showMessageDialog(this, "Error en el inicio de sesión. Verifica tu nombre de usuario y contraseña.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error en la conexión a la base de datos");
            
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
     String usuarioIngresado = jt.getText();
    String contraseñaIngresada = new String(jp.getPassword());

    
    String consultaVerificar = "SELECT * FROM registro WHERE usuario = ?";
    
    try {
        PreparedStatement pstVerificar = (PreparedStatement) cn.prepareStatement(consultaVerificar);
        pstVerificar.setString(1, usuarioIngresado);
        
        ResultSet rsVerificar = pstVerificar.executeQuery();

        if (rsVerificar.next()) {
            
            JOptionPane.showMessageDialog(this, "El nombre de usuario ya está registrado");
        } else {
           
            String consultaInsertar = "INSERT INTO registro (usuario, contrasena) VALUES (?, ?)";
            PreparedStatement pstInsertar = (PreparedStatement) cn.prepareStatement(consultaInsertar);
            pstInsertar.setString(1, usuarioIngresado);
            pstInsertar.setString(2, contraseñaIngresada);
            
            int filasAfectadas = pstInsertar.executeUpdate();

            if (filasAfectadas > 0) {
                JOptionPane.showMessageDialog(this, "Registro exitoso");
                 limpiar();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar el usuario");
            }
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error en la conexión a la base de datos: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_jToggleButton1ActionPerformed

     private void limpiar(){
        jp.setText("");
        jt.setText("");
       
    }
    public static void main(String args[]) {
       

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JPasswordField jp;
    private javax.swing.JTextField jt;
    // End of variables declaration//GEN-END:variables
}
