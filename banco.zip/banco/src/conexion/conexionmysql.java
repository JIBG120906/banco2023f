
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
public class conexionmysql {
    Connection cn;
    public Connection conectar (){
    
    try {
      Class.forName("com.mysql.jdbc.Driver");
       cn = DriverManager.getConnection(
          "jdbc:mysql://localhost:3306/banco", "root", "");
      System.out.println("conectado");
    } catch (Exception e) {
      System.out.println(e);
    }
        
    return cn;
  };
    
}
